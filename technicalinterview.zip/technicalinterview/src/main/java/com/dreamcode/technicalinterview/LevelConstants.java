package com.dreamcode.technicalinterview;

public class LevelConstants {
public static final ROOT_LEVEL = 0;
public static final CATEGORY_LEVEL = 1;
public static final SUBCATEGORY_LEVEL = 2;
}
