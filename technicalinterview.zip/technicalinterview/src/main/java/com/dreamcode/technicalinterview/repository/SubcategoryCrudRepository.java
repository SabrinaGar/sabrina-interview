package com.dreamcode.technicalinterview.repository;


import org.springframework.stereotype.Repository;

@Repository
public interface SubcategoryCrudRepository<Subcategory,long> {
}
