package com.dreamcode.technicalinterview.service;

public interface RootServiceImpl {
}
