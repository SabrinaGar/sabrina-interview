package com.dreamcode.technicalinterview.model;

import javax.persistence.*;

public class Subcategory extends AbstractRoot {


    public Subcategory(){

    }
    public Subcategory() {
        super();

    }
}