package com.dreamcode.technicalinterview.repository;

import org.springframework.data.repository.CrudRepository;

public interface KeywordCrudRepository extends CrudRepository<Keyword,long> {
}
