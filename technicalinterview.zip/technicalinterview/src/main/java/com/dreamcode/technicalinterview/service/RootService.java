package com.dreamcode.technicalinterview.service;

public class RootService {
}
